package main;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class AntiSpam {
	
	//Atributes
	
	private final double strongSpamThreshold;
	
	private final double weakSpamThreshold;
	
	//Derived atributes
	
	private final List<String> strongSpamWordsList;
	
	private final List<String> weakSpamThresholdList;
	
	private final boolean avoidSpam;
	
	//Constructor
	
	public AntiSpam(final String strongSpamWords, final double strongSpamThreshold, final String weakSpamWords, final double weakSpamThreshold, final String messages) {
		this.strongSpamThreshold = strongSpamThreshold;
		this.weakSpamThreshold = weakSpamThreshold;
		this.strongSpamWordsList = this.separateWords(strongSpamWords);
		this.weakSpamThresholdList = this.separateWords(weakSpamWords);
		this.avoidSpam = this.avoidSpamMethod(messages);
	}

	//Getters
	
	public double getStrongSpamThreshold() {
		return this.strongSpamThreshold;
	}
	
	public double getWeakSpamThreshold() {
		return this.weakSpamThreshold;
	}
	
	public List<String> getStrongSpamWordsList(){
		return this.strongSpamWordsList;
	}
	
	public List<String> getWeakSpamWordsList(){
		return this.weakSpamThresholdList;
	}
	
	public boolean getAvoidSpam() {
		return this.avoidSpam;
	}
	
	//Methods
	
	private List<String> separateWords (final String messages){
		List<String> result = null;
		
		final String[] separator = messages.split(",").clone();
		
		result = Arrays.asList(separator);
		
		result = result.stream().map(String::trim).collect(Collectors.toList());
		
		return result;
	}
	
	public boolean avoidSpamMethod(final String messages) {
		boolean result = false;
		
		final double lengthMessages = messages.split(" ").length;
		
		double countStrongSpamWords =0.; //this.strongSpamWordsList.stream().filter(messages::contains).count();
		
		for(final String spam : this.getStrongSpamWordsList()) {
			final String[] s = messages.toLowerCase().split(spam.toLowerCase());
			
			if(s.length == 0) {
				countStrongSpamWords += 1;
			}else if(s.length > 1) {
				countStrongSpamWords += s.length - 1.;
			}
			
		}
		
		final boolean overcomeThresholdStrongSpamWords = countStrongSpamWords/lengthMessages > this.getStrongSpamThreshold();
		
		if(overcomeThresholdStrongSpamWords) {
			result = true;
			return result;
		}
		
		double countWeakSpamWords = 0.; //this.weakSpamThresholdList.stream().filter(messages::contains).count();
		
		for(final String spam : this.getWeakSpamWordsList()) {
			final String[] s = messages.toLowerCase().split(spam.toLowerCase());
			
			if(s.length == 0) {
				countStrongSpamWords += 1;
			}else if(s.length > 1) {
				countWeakSpamWords += s.length - 1.;
			}
			
		}
		
		final boolean overcomeThresholdWeakSpamWords = countWeakSpamWords/lengthMessages > this.getWeakSpamThreshold();
		
		if(overcomeThresholdWeakSpamWords) {
			result = true;
			return result;
		}
		
	    return result;
	}
	
}